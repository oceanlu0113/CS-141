//Ocean Lu
//CS141
//Assignment 4
//11.15.17 

public interface Analyzable {
    double getAverage();
    GradedActivity getHighest();
    GradedActivity getLowest();
}

